define([`${localStorage['rsDebugUrl_c989r8dslxn2lui3'] || 'https://localhost:9001/js/app.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
