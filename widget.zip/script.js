define([`${localStorage['rsDebugUrl_c989r96klxoiyc8a'] || 'https://localhost:9000/js/app.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
