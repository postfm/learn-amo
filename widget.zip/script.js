define([`${localStorage['rsDebugUrl_c989r9lslxomw2id'] || './build/js/app.a2cc1b84.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
